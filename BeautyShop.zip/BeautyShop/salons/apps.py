from django.apps import AppConfig


class SalonsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'salons'
