from django.contrib import admin

from .models import (
    Salon,
    Social
)

admin.site.register(Salon)
admin.site.register(Social)